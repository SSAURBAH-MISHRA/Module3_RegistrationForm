package com.capgemini.Test;

import org.junit.runner.RunWith;

import cucumber.api.junit.Cucumber;

//	Runnner class to run as the JUnit Test
@RunWith(Cucumber.class)
public class RunnerClass {

}
