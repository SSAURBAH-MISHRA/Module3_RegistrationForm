package com.capgemini.Test;

import static org.junit.Assert.assertEquals;

import com.capgemini.pages.RegistrationFormPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

//	Step Definition class of registrationForm.feature file
public class RegistrationFormTest {
	RegistrationFormPage registrationFormPage;

	@Given("^User open the web browser\\.$")
	public void user_open_the_web_browser() throws InterruptedException {
		registrationFormPage = new RegistrationFormPage();

	}

	@Given("^Open the RegistrationForm\\.html page\\.$")
	public void open_the_RegistrationForm_html_page() throws Throwable {

		registrationFormPage.openRegistrationFormPage();
	}

	@Then("^validate the page title as \"([^\"]*)\"\\.$")
	public void validate_the_page_title_as(String arg1) throws Throwable {
		assertEquals(arg1, registrationFormPage.getTitle());
		Thread.sleep(2000);
		registrationFormPage.quitPage();

	}

	@When("^Submit button is clicked upon wrong or no User Id entered in the text box\\.$")
	public void submit_button_is_clicked_upon_wrong_or_no_User_Id_entered_in_the_text_box() throws Throwable {

		registrationFormPage.setUserId(""); // no User Id entered
		registrationFormPage.clickSubmitButton();
	}

	@Then("^validate the message as \"([^\"]*)\"$")
	public void validate_the_message_as(String arg1) throws Throwable {

		String alertMessage = registrationFormPage.getMessage();
		if (alertMessage != null)
			assertEquals(alertMessage, arg1);
		Thread.sleep(2000);
		registrationFormPage.quitPage();

	}

	@When("^Submit button is clicked upon wrong or no Password entered in the text box\\.$")
	public void submit_button_is_clicked_upon_wrong_or_no_Password_entered_in_the_text_box() throws Throwable {

		registrationFormPage.setUserId("10011");
		registrationFormPage.setPassword(""); 		// no Password entered
		registrationFormPage.clickSubmitButton();
	}

	@When("^Submit button is clicked upon wrong or no Name entered in the text box\\.$")
	public void submit_button_is_clicked_upon_wrong_or_no_Name_entered_in_the_text_box() throws Throwable {

		registrationFormPage.setUserId("10011");
		registrationFormPage.setPassword("password");
		registrationFormPage.setUserName(""); 		// no User name entered
		registrationFormPage.clickSubmitButton();
	}

	@When("^Submit button is clicked upon wrong or no Address entered in the text box\\.$")
	public void submit_button_is_clicked_upon_wrong_or_no_Address_entered_in_the_text_box() throws Throwable {

		registrationFormPage.setUserId("10011");
		registrationFormPage.setPassword("password");
		registrationFormPage.setUserName("Username");
		registrationFormPage.setAddress(""); 		// no Address entered
		registrationFormPage.clickSubmitButton();
	}

	@When("^Submit button is clicked upon no Country selected from the dropdown box\\.$")
	public void submit_button_is_clicked_upon_no_Country_selected_from_the_dropdown_box() throws Throwable {

		registrationFormPage.setUserId("10011");
		registrationFormPage.setPassword("password");
		registrationFormPage.setUserName("Username");
		registrationFormPage.setAddress("Pune");
		registrationFormPage.setCountry("(Please select a country)"); // no Country is selected
		registrationFormPage.clickSubmitButton();
	}

	@When("^Submit button is clicked upon wrong Zip Code entered in the text box\\.$")
	public void submit_button_is_clicked_upon_wrong_Zip_Code_entered_in_the_text_box() throws Throwable {

		registrationFormPage.setUserId("10011");
		registrationFormPage.setPassword("password");
		registrationFormPage.setUserName("Username");
		registrationFormPage.setAddress("Pune");
		registrationFormPage.setCountry("India");
		registrationFormPage.setZipCode("+91"); 		// wrong ZipCode entered
		registrationFormPage.clickSubmitButton();
	}

	@When("^Submit button is clicked upon wrong Email Id entered in the text box\\.$")
	public void submit_button_is_clicked_upon_wrong_Email_Id_entered_in_the_text_box() throws Throwable {

		registrationFormPage.setUserId("10011");
		registrationFormPage.setPassword("password");
		registrationFormPage.setUserName("Username");
		registrationFormPage.setAddress("Pune");
		registrationFormPage.setCountry("India");
		registrationFormPage.setZipCode("91");
		registrationFormPage.setEmailId("xyzgmailcom");		 // no Email Id entered
		registrationFormPage.clickSubmitButton();
	}

	@When("^Submit button is clicked upon non selection of gender\\.$")
	public void submit_button_is_clicked_upon_non_selection_of_gender() throws Throwable {

		registrationFormPage.setUserId("10011");
		registrationFormPage.setPassword("password");
		registrationFormPage.setUserName("Username");
		registrationFormPage.setAddress("Pune");
		registrationFormPage.setCountry("India");
		registrationFormPage.setZipCode("91");
		registrationFormPage.setEmailId("xyz@gmail.com");
		registrationFormPage.setLanguage(); 		// no Gender selected
		registrationFormPage.clickSubmitButton();
	}

	@Given("^Select the language as English\\.$")
	public void select_the_language_as_English() throws Throwable {

		registrationFormPage.setUserId("10011");
		registrationFormPage.setPassword("password");
		registrationFormPage.setUserName("Username");
		registrationFormPage.setAddress("Pune");
		registrationFormPage.setCountry("India");
		registrationFormPage.setZipCode("91");
		registrationFormPage.setEmailId("xyz@gmail.com");
		registrationFormPage.setGender();
		registrationFormPage.setLanguage(); 		// English is selected as Language
		registrationFormPage.clickSubmitButton();
	}

	@When("^Submit button is clicked upon all the details entered correctly\\.$")
	public void submit_button_is_clicked_upon_all_the_details_entered_correctly() throws Throwable {

		registrationFormPage.setUserId("10011");
		registrationFormPage.setPassword("password");
		registrationFormPage.setUserName("Username");
		registrationFormPage.setAddress("Pune");
		registrationFormPage.setCountry("India");
		registrationFormPage.setZipCode("91");
		registrationFormPage.setEmailId("xyz@gmail.com");
		registrationFormPage.setGender();
		registrationFormPage.setLanguage(); 		// Submit button is clicked
		registrationFormPage.clickSubmitButton();	 // when all details are entered correctly
	}

}
