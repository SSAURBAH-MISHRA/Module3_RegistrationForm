package com.capgemini.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.capgemini.TestBase.TestBase;

public class RegistrationFormPage {

	WebDriver driver;

	// Location of UI elements using appropriate locators.
	@FindBy(name = "userid")
	WebElement userid;

	@FindBy(name = "passid")
	WebElement password;

	@FindBy(name = "username")
	WebElement userName;

	@FindBy(name = "address")
	WebElement address;

	@FindBy(name = "country")
	WebElement country;

	@FindBy(name = "zip")
	WebElement zipCode;

	@FindBy(name = "email")
	WebElement emailId;

	@FindBy(name = "submit")
	WebElement submitButton;

	// method to load the driver
	public RegistrationFormPage() throws InterruptedException {
		super();
		driver = TestBase.Initialisation();
	}

	// method to open the RegistrationForm.html page
	public void openRegistrationFormPage() throws InterruptedException {
		String projectLocation = System.getProperty("user.dir");
		driver.get(projectLocation + "\\WebContent\\RegistrationForm.html");
		PageFactory.initElements(driver, this);
		Thread.sleep(1000);
	}

	// method to get the title of RegistrationForm.html page
	public String getTitle() {
		return driver.getTitle();
	}

	// method to set the data in different UI elements
	public void setUserId(String string) {
		userid.click();
		userid.sendKeys(string);
	}

	public void setPassword(String string) {
		password.click();
		password.sendKeys(string);
	}

	public void setUserName(String string) {
		userName.click();
		userName.sendKeys(string);
	}

	public void setAddress(String string) {
		address.click();
		address.sendKeys(string);
	}

	public void setCountry(String string) {
		Select country1 = new Select(country);
		country1.selectByVisibleText(string);
	}

	public void setZipCode(String string) {
		zipCode.click();
		zipCode.sendKeys(string);
	}

	public void setEmailId(String string) {
		emailId.click();
		emailId.sendKeys(string);
	}

	public void setGender() {
		WebElement gender = driver.findElement(By.cssSelector("input[value='Male']"));
		gender.click();
	}

	public void setLanguage() {
		WebElement language = driver.findElement(By.cssSelector("input[value='en']"));
		language.click();
		language.click();
	}

	// method to click the submit button
	public void clickSubmitButton() {
		submitButton.click();
	}

	// method to close the browser window
	public void quitPage() {
		driver.close();
	}

	// method to get the alert message
	public String getMessage() {
		String alertMessage = null;
		if (this.isAlertPresent()) {
			alertMessage = driver.switchTo().alert().getText();
			driver.switchTo().alert().accept();
		}
		return alertMessage;
	}

	public boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

}
